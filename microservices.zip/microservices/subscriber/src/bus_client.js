const msb = require('msb');

const subscribe = () => {
  return msb.channelManager.findOrCreateConsumer(process.env.EVENT_SUBSCRIBE, {
    type: 'topic',
    bindingKeys: 'all',
    autoConfirm: false,
    durable: process.env.TMP_QUEUE !== 'true',
    prefetchCount: 1
  });
};

module.exports = {
  subscribe,
};