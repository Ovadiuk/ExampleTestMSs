require('dotenv-extended').load({errorOnMissing: true});
const subscriber = require('./bus_client').subscribe();
const axios = require('axios').default;

const sendMessageToExternalSystem = async (message) => {
  console.log('sending message', message);

  await axios.post(process.env.EXT_SYSTEM_URL + '/' + process.env.EXT_SYSTEM_URN, message);
};

subscriber.on('message', message => {
  sendMessageToExternalSystem(message.payload)
    .then(() => {
      subscriber.confirmProcessedMessage(message);
      subscriber.emit('confirmProcessedMessage', message);
    })
    .catch(err => {
      console.error(err, 'Reject a message');
      subscriber.rejectMessage(message);
    });
});

subscriber.on('error', err => {
  console.error(err, 'Reject a message');
});

module.exports = {
  subscriber,
};