require('dotenv-extended').load({errorOnMissing: true});
const subscriber = require("../src/app").subscriber;
const msb = require('msb');
const {assert} = require('chai');
const nock = require('nock');

describe('Microservice', () => {

  it('should send message to external system', (done) => {
    const event  = {message: 'hello'};

    nock(process.env.EXT_SYSTEM_URL).post('/' + process.env.EXT_SYSTEM_URN).reply(200);

    subscriber.on('confirmProcessedMessage', (message) => {
      assert.deepEqual(message.payload, event);
      console.log('message processed successfully');
      done();
    });

    publishTestMessage(event);
  });

});

function publishTestMessage(payload) {
  // create a message
  const topic = process.env.EVENT_SUBSCRIBE;
  const routingKey = 'all';

  const message = msb.messageFactory
    .createBroadcastMessage({namespace: topic});
  message.payload = payload;
  message.topics.routingKey = routingKey;

  // publish the message
  return msb.channelManager
    .findOrCreateProducer(topic)
    .publish(message, (err) => {
      if (err) return err;
    });
}