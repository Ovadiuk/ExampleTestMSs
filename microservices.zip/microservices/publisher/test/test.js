require('dotenv-extended').load({errorOnMissing: true});
const app = require('../src/app');
const request = require('supertest');
const {assert} = require('chai');
const msb = require('msb');

let consumer;

before('subscribe', done => {
  consumer = msb.createChannelManager().findOrCreateConsumer("event:middleware", {
    type: 'topic',
    bindingKeys: 'all'
  });
  consumer.onceConsuming(done);
});

after(async () => {
  app.httpServer.close();
  consumer.raw.close();
});

describe('Integration test', async () => {
  it('Should publish message to rabbitmq', (done) => {
    const event = {message: 'hello'};

    consumer.once('message', (message) => {
      console.log(message);
      assert.deepEqual(message.payload, event);
      console.log(message.topics.routingKey);
      done();
    });

    request(app.httpServer)
      .post('/item')
      .send(event)
      .end((err, resp) => {
        if (err) return done(err);
        assert.equal(resp.statusCode, 200);
      });

  });
});
