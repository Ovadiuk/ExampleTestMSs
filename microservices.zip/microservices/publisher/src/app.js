require('dotenv-extended').load({errorOnMissing: true});
const Koa = require('koa');
const bodyParser = require('koa-bodyparser');
const Router = require('koa-router');
const busClient = require('./bus_client');

const postItemToBus = async (ctx) => {
  console.log('published message:', ctx.request.body);
  await busClient.publishEvent(ctx.request.body);
  ctx.body = {
    result: 'OK'
  }
};

const router = new Router();
router.post('/item', postItemToBus);

const app = {};
app.koaApp = new Koa();
app.koaApp.use(bodyParser());
app.koaApp.use(router.routes());
app.koaApp.use(router.allowedMethods());

app.httpServer = app.koaApp.listen(process.env.HTTP_PORT);
console.log('Microservice started on port 3301\n');

app.httpServer.on('close', () => {
  busClient.producer.close();
  console.log('\nMicroservice stopped');
});

module.exports = app;



