const msb = require('msb');

const producer = msb.channelManager.findOrCreateProducer(process.env.EVENT_NAMESPACE, {type: 'topic'});

function publish(event) {
  return new Promise((resolve, reject)=> {
    const message = msb.messageFactory.createBroadcastMessage({namespace: process.env.EVENT_NAMESPACE, routingKey: 'all'});
    message.payload = event;
    message.topics.routingKey = 'all';
    // console.log('Start an attempt to send a message');

    producer.publish(message, (error) => {
        if (error) return reject(error);
        // console.log('Send a message: ', message.payload);
        resolve();
      });
  });
}

module.exports = {
  publishEvent: publish.bind(undefined),
  producer,
};
