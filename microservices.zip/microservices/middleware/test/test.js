require('dotenv-extended').load({errorOnMissing: true});
require('../src/app');
const {assert} = require('chai');
const msb = require('msb');

describe('Microservice', () => {
  let consumer;

  before((done) => {
    consumer = msb.createChannelManager().findOrCreateConsumer(process.env.EVENT_PUBLISH, {
      type: 'topic',
      bindingKeys: 'all'
    });
    consumer.onceConsuming(done);
  });

  it('should subscribe, process message, and send it', (done) => {
    const event = {message: 'hello'};
    consumer.once('message', (message) => {
      assert.deepEqual(message.payload, event);
      done();
    });

    publishTestMessage(event);
  });

});

function publishTestMessage(payload) {
  // create a message
  const topic = process.env.EVENT_SUBSCRIBE;
  const routingKey = 'all';

  const message = msb.messageFactory
    .createBroadcastMessage({namespace: topic});
  message.payload = payload;
  message.topics.routingKey = routingKey;

  // publish the message
  msb.channelManager
    .findOrCreateProducer(topic)
    .publish(message, (err) => {
      if (err) return err;
    });
}