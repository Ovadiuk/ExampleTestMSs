require('dotenv-extended').load({errorOnMissing: true});
const subscriber = require('./bus_client').subscribe();
const publish = require('./bus_client').publish;

const processMessage = async (message) => {
  console.log("processing message:", message);
  return message.payload;
};

subscriber.on('message', message => {
  processMessage(message)
    .then(publish)
    .then(() => subscriber.confirmProcessedMessage(message))
    .catch(err => {
      console.log(err);
      subscriber.rejectMessage(message);
    })
});

subscriber.on('error', err => {
  console.error(err, 'Reject a message');
});