const msb = require('msb');

const subscribe = () => {
  return msb.channelManager.findOrCreateConsumer(process.env.EVENT_SUBSCRIBE, {
    type: 'topic',
    bindingKeys: 'all',
    autoConfirm: false,
    durable: process.env.TMP_QUEUE !== 'true',
    prefetchCount: 1
  });
};

const publish = (event) => {
  return new Promise((resolve, reject) => {
    const message = msb.messageFactory.createBroadcastMessage({namespace: process.env.EVENT_PUBLISH, routingKey: 'all'});
    message.payload = event;
    message.topics.routingKey = 'all';

    const producer = msb.channelManager.findOrCreateProducer(process.env.EVENT_PUBLISH, {type: 'topic'});
    producer.publish(message, (error) => {
      if (error) return reject(error);
      resolve();
    });
  });
};

module.exports = {
  subscribe,
  publish,
};